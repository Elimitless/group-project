import os
import sqlite3

import stripe
from flask import Flask, request, jsonify
from flask_login import LoginManager, UserMixin, login_required, current_user
from flask_mail import Mail, Message

app = Flask(__name__)

# Mail Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_USERNAME')
mail = Mail(app)

# Stripe Configuration
stripe.api_key = os.getenv('STRIPE_SECRET_KEY')

# Flask-Login Configuration
app.secret_key = 'your_secret_key'
login_manager = LoginManager(app)

# Database Initialization
def init_db():
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS flights (
                        flight_id INTEGER PRIMARY KEY,
                        origin TEXT,
                        destination TEXT,
                        date TEXT,
                        seats_available INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS reservations (
                        reservation_id INTEGER PRIMARY KEY,
                        flight_id INTEGER,
                        customer_id INTEGER,
                        FOREIGN KEY (flight_id) REFERENCES flights (flight_id))''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
                        customer_id INTEGER PRIMARY KEY,
                        name TEXT,
                        email TEXT,
                        password TEXT)''')  # Assume passwords are stored hashed
    cursor.execute('''CREATE TABLE IF NOT EXISTS payments (
                        payment_id INTEGER PRIMARY KEY,
                        reservation_id INTEGER,
                        amount REAL,
                        status TEXT,
                        FOREIGN KEY (reservation_id) REFERENCES reservations (reservation_id))''')
    conn.commit()
    conn.close()

# User Loader
class User(UserMixin):
    def __init__(self, id, name, email):
        self.id = id
        self.name = name
        self.email = email

@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers WHERE customer_id=?", (user_id,))
    user_row = cursor.fetchone()
    conn.close()
    return User(user_row[0], user_row[1], user_row[2]) if user_row else None

# Routes
@app.route('/search_flights', methods=['GET'])
def search_flights():
    origin = request.args.get('origin')
    destination = request.args.get('destination')
    date = request.args.get('date')
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM flights WHERE origin=? AND destination=? AND date=? AND seats_available > 0''', 
                   (origin, destination, date))
    flights = cursor.fetchall()
    conn.close()
    return jsonify(flights)

@app.route('/book_flight', methods=['POST'])
@login_required
def book_flight():
    flight_id = request.json['flight_id']
    customer_id = current_user.id
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO reservations (flight_id, customer_id) VALUES (?, ?)''', (flight_id, customer_id))
    cursor.execute('''UPDATE flights SET seats_available = seats_available - 1 WHERE flight_id=?''', (flight_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Reservation successful"}), 201

@app.route('/process_payment', methods=['POST'])
@login_required
def process_payment():
    data = request.json
    reservation_id = data['reservation_id']
    amount = data['amount'] * 100  # Convert to cents
    payment_method_id = data['payment_method_id']
    try:
        intent = stripe.PaymentIntent.create(
            amount=amount,
            currency='usd',
            payment_method=payment_method_id,
            confirmation_method='automatic',
            confirm=True,
        )
        # Store payment details in the database
        conn = sqlite3.connect('airline_reservation.db')
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO payments (reservation_id, amount, status) VALUES (?, ?, ?)''',
                       (reservation_id, amount / 100, 'Completed'))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Payment successful', 'paymentIntent': intent}), 200
    except stripe.error.CardError as e:
        return jsonify({'error': str(e.user_message)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/cancel_flight/<int:reservation_id>', methods=['DELETE'])
@login_required
def cancel_flight(reservation_id):
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT c.email, f.flight_number, f.date, f.origin, f.destination 
                      FROM reservations r
                      JOIN customers c ON r.customer_id = c.customer_id
                      JOIN flights f ON r.flight_id = f.flight_id
                      WHERE r.reservation_id = ?''', (reservation_id,))
    reservation = cursor.fetchone()
    if not reservation:
        return jsonify({'error': 'Reservation not found'}), 404
    customer_email = reservation[0]
    flight_details = {
        'flight_number': reservation[1],
        'date': reservation[2],
        'origin': reservation[3],
        'destination': reservation[4]
    }
    cursor.execute('''DELETE FROM reservations WHERE reservation_id=?''', (reservation_id,))
    cursor.execute('''UPDATE flights SET seats_available = seats_available + 1 
                      WHERE flight_id=(SELECT flight_id FROM reservations WHERE reservation_id=?)''', (reservation_id,))
    conn.commit()
    conn.close()
    send_cancellation_email(customer_email, flight_details)
    return jsonify({'message': 'Flight cancelled and notification sent'}), 200

def send_cancellation_email(customer_email, flight_details):
    msg = Message("Flight Cancellation Notification", recipients=[customer_email])
    msg.body = f"""
    Dear Customer,

    We regret to inform you that your flight has been canceled. Here are the details:

    Flight: {flight_details.get('flight_number')}
    Date: {flight_details.get('date')}
    From: {flight_details.get('origin')}
    To: {flight_details.get('destination')}

    We apologize for any inconvenience this may cause. Please feel free to contact our customer service for more assistance.

    Best Regards,
    Airline Support Team
    """
    mail.send(msg)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)