import os
import sqlite3

import stripe
from dotenv import load_dotenv
from flask import Flask, request, render_template
from flask_login import LoginManager, UserMixin
from flask_mail import Mail

# Load environment variables from .env file
load_dotenv()

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_default_secret_key')

# Stripe configuration
stripe.api_key = os.getenv('STRIPE_SECRET_KEY')

# Mail configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_USERNAME')
mail = Mail(app)

# Flask-Login configuration
login_manager = LoginManager(app)


# User loader
class User(UserMixin):
    def __init__(self, id, name, email):
        self.id = id
        self.name = name
        self.email = email


@login_manager.user_loader
def load_user(user_id):
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers WHERE customer_id=?", (user_id,))
    user_row = cursor.fetchone()
    conn.close()
    return User(user_row[0], user_row[1], user_row[2]) if user_row else None


# Database initialization
def init_db():
    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS flights (
        flight_id INTEGER PRIMARY KEY,
        origin TEXT,
        destination TEXT,
        date TEXT,
        seats_available INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS reservations (
        reservation_id INTEGER PRIMARY KEY,
        flight_id INTEGER,
        customer_id INTEGER,
        FOREIGN KEY (flight_id) REFERENCES flights (flight_id))''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
        customer_id INTEGER PRIMARY KEY,
        name TEXT,
        email TEXT,
        password TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS payments (
        payment_id INTEGER PRIMARY KEY,
        reservation_id INTEGER,
        amount REAL,
        status TEXT,
        FOREIGN KEY (reservation_id) REFERENCES reservations (reservation_id))''')
    conn.commit()
    conn.close()


# Function to add an assortment of flights to the database
def add_flights():
    flights_data = [
        ('New York', 'Los Angeles', '2024-10-11', 100),
        ('Chicago', 'Miami', '2024-11-12', 50),
        ('San Francisco', 'Las Vegas', '2024-11-13', 75),
        ('Houston', 'Seattle', '2024-11-14', 60),
        ('Denver', 'New York', '2024-11-15', 80),
        ('Boston', 'Chicago', '2024-11-66', 90),
        ('Atlanta', 'Dallas', '2024-11-17', 30),
    ]

    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()

    cursor.executemany('''INSERT INTO flights (origin, destination, date, seats_available)
                          VALUES (?, ?, ?, ?)''', flights_data)

    conn.commit()
    conn.close()


# Routes
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/search_flights', methods=['GET'])
def search_flights():
    origin = request.args.get('origin')
    destination = request.args.get('destination')
    date = request.args.get('date')

    conn = sqlite3.connect('airline_reservation.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM flights WHERE origin=? AND destination=? AND date=? 
    AND seats_available > 0''', (origin, destination, date))
    flights = cursor.fetchall()
    conn.close()

    return render_template('search_flights.html', flights=flights)  # Render a new template with the results


# Main block
if __name__ == '__main__':
    init_db()  # Initialize the database on startup if not already created
    add_flights()  # Populate database with initial flights data
    app.run(debug=True)
